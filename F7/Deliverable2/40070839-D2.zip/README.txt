Software Engineering Processes

Documentation - Includes the latex and pdf file of the deliverable 2 report.
Source_Files - Contains the source files for the project.
Function7 - The executable jar file which executes the program.

How to run

1. Double click on the Function7.jar to start the program

Or
1. Open command window and change the path to the folder
2. Type "java -jar Function7.jar" without quotes to execute.

Student Name : Himanshu Kohli
Student ID : 40070839
Student Email : atomicboy2012@gmail.com

 