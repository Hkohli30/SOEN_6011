

/**
 * @author @Himanshu Kohli
 */

/**
 * Empty Interface for Memento Pattern 
 * CareTaker Interface
 */
public interface CareTaker {}
